## vue实现前后台数据交互的方法

Ajax      fetch

##### vue-resource (vue1.0) 

体积小

支持主流浏览器

支持promise API 和URI templates

支持拦截器

需要安装

npm i vue-resource -D

入口文件中 引入   

```vue
//引入
npm install vue-resource -D

import vueResource from 'vue-resource'
Vue.use(vueResource)

mounted(){
  this.$http.post('http://www.qhdlink-student.top/student/coach.php','username=zyp&userpwd=123456&userclass=64&type=4',{
    headers:{"content-type":"application/x-www-form-urlencoded"},
  }).then(function(rep){
    console.log(rep)
  },function (err) {
    console.log(err+'错')
  })
}
```



### axios(vue2.06)

###### 		Axios是基于promise的HTTP库，可以用在浏览器和node.js中

#### 特点

从浏览器中创建XMLHttpRequest

从node.js创建http请求

支持promise API

拦截请求和响应

转换请求数据和响应数据

取消请求数据和响应数据

取消请求

自动转换Josn数据

客户端支持防御XSRF

```
//下载引入

npm install axios -D
import Axios from 'axios'
Vue.prototype.$axios=Axios

 this.$axios({
   url:'http://www.qhdlink-student.top/student/coach.php',
   method:"post",
   headers:{'Content-type':'application/x-www-form-urlencoded'},
   data:'username=zyp&userpwd=123456&userclass=64&type=4',
 }).then((req)=>{
   console.log(req)
 })              
```

####  拦截器

1) 在请求或响应被 then 或 catch 处理前拦截它们。

2) // 添加请求拦截器

axios.interceptors.request.use(function (config) {

  // 在发送请求之前做些什么

  return config;

 }, function (error) {

  // 对请求错误做些什么

  return Promise.reject(error);

 });

3) // 添加响应拦截器

axios.interceptors.response.use(function (response) {

 // 对响应数据做点什么

  return response;

 }, function (error) {

  // 对响应错误做点什么

  return Promise.reject(error);

 	});

4) 移除拦截器

var myInterceptor = axios.interceptors.request.use(function () {/*...*/});

axios.interceptors.request.eject(myInterceptor);