## Vue-路由

通过监听地址栏地址变化，跳转页面

##### 安装

npm install vue-router

##### 引入  

```vue
import VueRouter from 'vue-router'

Vue.use(VueRouter)

```

##### 动态匹配

$router.query

类型：object

