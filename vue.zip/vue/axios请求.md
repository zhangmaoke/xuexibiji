# axios请求

```vue
//nav请求

<template>
  <div id="app">
        <ul>
            <li v-for="yi in name" :key="yi.id_m">
                <a :href="yi.addr_m">{{yi.title_m}}</a>
                <ul v-if="yi.type==1">
                    <li v-for="(er,index) in yi.children_m" :key="index">
                        <a :href="er.addr_c">{{er.title_c}}</a>
                    </li>
                </ul>
            </li>
        </ul>
  </div>
</template>

<script>
// import { filter } from 'vue/types/umd'

export default {
  name: 'Zuoye',
  data:function(){
      return{
          'name':'',

      }
    },
    mounted(){
        this.$axios({
            url:' http://www.qhdlink-student.top/test/nav.php',
            method:"get",
            headers:{'Content-type':'application/x-www-form-urlencoded'},
            // data:'username=zyp&userpwd=123456&userclass=64&type=4',

        }).then((req)=>{  //用箭头函数
              console.log(req.data)
              this.name=req.data   
        })
    }
}


</script>
<style>

</style>


```

