- [x] # Vue计算属性和样式绑定

##### 侦听属性 watch：侦听数据的变化

###### wacth属性是用来观察和响应vue实例上的数据变动，当你有些数据需要随着其他数据变动而变动，一个		watch函数只能侦听一个数据变化

------

##### 用watch侦听one，one中的值一改变就改变

![image-20210421090142983](C:\Users\zmk\AppData\Roaming\Typora\typora-user-images\image-20210421090142983.png) 

------

#### 计算属性

vue.js的内链表达式非常方便。但它最适合的使用场景是简单的布尔操作或字符串拼接。如果涉及更复杂的逻辑，在模板中放入太多的逻辑会让模板过重且难以维护。使用侦听属性，只能针对指定的数据，无法重用，所以，对于任何复杂逻辑，你都应当使用计算属性

计算属性是用来声明式的描述一个值依颡了其它的值。当你在模板里把数据绑定到一个计算属性上时，Vue 会在其依赖的任何值导致该计算属性改变时更新DOM。这个功能非常强大,可的代码更加声明式、数据驱动并且易于维护。





计算属性关键字computed

![image-20210421092329066](C:\Users\zmk\AppData\Roaming\Typora\typora-user-images\image-20210421092329066.png)



getter : 获取属性的方法

setter：设置属性的方法



##### metheds和computed的区别

------

computed是基于他的依赖缓存，只有相关依赖发生改变时才会重新取值，而使用metheds，在重新渲染的时候，函数总会重新调用执行。

使用metheds，在调用的时候要写方法的调用方式 方法名()

------

# 样式绑定	

##### 数据绑定一个常见需求是操作元素的class列表和他的内嵌样式。

限制作用域的属性 scoped

语法格式 ：v-bind:class=“对象”

​	1、为v-bind：class

​	4、可以绑定返回对象的计算属性，这是一个常用且强大的模式

​	5、可以把一个数组传个v-bind:class ="[类都生效]"





##### 绑定内联样式

​	1、直接设置样式

![image-20210421103553602](C:\Users\zmk\AppData\Roaming\Typora\typora-user-images\image-20210421103553602.png)

​	

2、可以动态改变   使用小驼峰命名法   例：font-size=fontSize

![image-20210421103756003](C:\Users\zmk\AppData\Roaming\Typora\typora-user-images\image-20210421103756003.png)

3、使用数组将多个样式对象应用到一个元素上





引入子组件 ，定义局部条件，调用

# 事件修饰符

.stop  阻止冒泡

.prevent 阻止默认事件

.capture 捕获时间

.self 元素本身触发

.once  执行一次

#### 按键修饰符

​	.enter

​	.tab

​	.delete（捕获 “删除“和”退格”键）

​	.esc

​	.space

​	.up

​	.down

​	.left

​	.right